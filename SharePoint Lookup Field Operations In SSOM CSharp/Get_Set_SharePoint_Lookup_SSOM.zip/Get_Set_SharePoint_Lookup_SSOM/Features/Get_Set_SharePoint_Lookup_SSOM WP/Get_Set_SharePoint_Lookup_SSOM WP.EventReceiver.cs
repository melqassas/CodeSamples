using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebPartPages;

namespace Get_Set_SharePoint_Lookup_SSOM.Features.Feature3
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("afcef67f-1ed1-4fb9-ab92-c029662d5449")]
    public class Feature3EventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        //public override void FeatureActivated(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSite site = properties.Feature.Parent as SPSite;
            using (SPWeb web = site.OpenWeb())
            {
                using (SPLimitedWebPartManager wpManager = web.GetLimitedWebPartManager("/Lists/LookupField/AllItems.aspx", System.Web.UI.WebControls.WebParts.PersonalizationScope.Shared))
                {
                    Get_Set_SharePoint_Lookup_SSOM.Get_Set_LookupField.Get_Set_LookupField webpart = new Get_Set_SharePoint_Lookup_SSOM.Get_Set_LookupField.Get_Set_LookupField();
                    //webpart.ZoneID = "Top";
                    webpart.Title = "Lookup Field Operation";
                    wpManager.AddWebPart(webpart,"Main", 0);
                }
            }
        }
    }
}
