﻿using Microsoft.SharePoint;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data;

namespace Get_Set_SharePoint_Lookup_SSOM.Get_Set_LookupField
{
    public partial class Get_Set_LookupFieldUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    // bind lookups
                    bind();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        protected void rd_get_set_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //Clear result
                lbl_result.Text = "";
                //fill the lookups
                if (rd_get_set.SelectedIndex == 0)
                {
                    pnl_SetLF.Visible = true;
                    pnl_GetLF.Visible = false;
                }
                else if (rd_get_set.SelectedIndex == 1)
                {
                    pnl_SetLF.Visible = false;
                    pnl_GetLF.Visible = true;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void bind()
        {
            //Fill the entries
            SPSite site = SPContext.Current.Site;
            SPWeb web = site.OpenWeb();
            SPList list = web.Lists["LookupList"];
            //dropdown
            dl_lookup.DataSource = list.Items;
            dl_lookup.DataValueField = "ID"; // 
            dl_lookup.DataTextField = "Title";
            dl_lookup.DataBind();

            //Checkbox
            cb_lookupM.DataSource = list.Items;
            cb_lookupM.DataValueField = "ID"; // 
            cb_lookupM.DataTextField = "Title";
            cb_lookupM.DataBind();
           

        }


        protected void btn_Get_Click(object sender, EventArgs e)
        {
            try
            {
                //Clear  
                lbl_result.Text = "";
                //Get List Item
                SPSite site = SPContext.Current.Site;
                SPWeb web = site.OpenWeb();
                SPList list = web.Lists["LookupField"];
                SPListItem item = list.GetItemById(Int32.Parse(txt_ID.Text));
                //Get Text field
                if (item != null)
                {
                    lbl_title.Text = item["Title"].ToString();
                    
                    //Get Lookup Field - Single Value
                    SPFieldLookupValue SingleValue = new SPFieldLookupValue(item["LookupFieldSingleValue"].ToString());
                    lbl_lokupSID.Text = SingleValue.LookupId.ToString();
                    lbl_lokupS.Text = SingleValue.LookupValue;
                    
                    
                    //Get Lookup Field - Multiple Value
                    dl_lookupM.Items.Clear();
                    SPFieldLookupValueCollection MultipleValues = item["LookupFieldMultipleValue"] as SPFieldLookupValueCollection;
                    foreach (SPFieldLookupValue itemValue in MultipleValues)
                    {
                        ListItem  litem = new ListItem();
                        litem.Text= itemValue.LookupValue;
                        litem.Value = itemValue.LookupId.ToString();
                        dl_lookupM.Items.Add(litem);
                    }
                }
                else
                {
                    lbl_result.Text = "Make Sure that you have provided a correct ItemID";
                }
            }
            catch (Exception w)
            {
                lbl_result.Text = w.Message.ToString();
            }
        }

        protected void btn_set_Click1(object sender, EventArgs e)
        {
            try
            {
                //Clear  
                lbl_result.Text = "";
                //Get List Item
                SPSite site = SPContext.Current.Site;
                SPWeb web = site.OpenWeb();
                SPList list = web.Lists["LookupField"];
                SPListItem item = list.Items.Add();
                web.AllowUnsafeUpdates = true;

                item["Title"] = txt_title.Text;
                //Set Lookup Field - Single Value

                item["LookupFieldSingleValue"] = new SPFieldLookupValue(Int32.Parse(dl_lookup.SelectedItem.Value), dl_lookup.SelectedItem.Text);

                //Set Lookup Field - Multiple Value
                SPFieldLookupValueCollection itemValues = new SPFieldLookupValueCollection();
                foreach (ListItem litem in cb_lookupM.Items)
                {
                    if (litem.Selected)
                    {
                        itemValues.Add(new SPFieldLookupValue(Int32.Parse(litem.Value), litem.Text)); 
                    }
                }
                
                item["LookupFieldMultipleValue"] = itemValues;
                item.Update();
                Response.Redirect(Request.RawUrl);
            }
            catch (Exception w)
            {
                lbl_result.Text = w.Message.ToString();
            }
        }
    }
}
